//
//  tagutils-dsf.h
//  
//
//  Created by inXtro, Inc on 13/8/27.
//
//	

static int _get_dsftags(char *file, struct song_metadata *psong);
static int _get_dsffileinfo(char *file, struct song_metadata *psong);




