//
//  tagutils-dff.h
//  
//
//  Created by inXtro, Inc on 13/8/27.
//
//	

static int _get_dfftags(char *file, struct song_metadata *psong);
static int _get_dfffileinfo(char *file, struct song_metadata *psong);

int Get_DffID3_Info(char *file);




